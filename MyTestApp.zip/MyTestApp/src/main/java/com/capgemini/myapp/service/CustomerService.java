package com.capgemini.myapp.service;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.myapp.dto.Customer;

public class CustomerService {


public void viewDetails(List<Customer> customer)
{
	 for(Customer c:customer)
	  {
		  System.out.println("customerId : "+c.getCustid()+"  "+"customerName : "+c.getCustname()+"  "+"customerContact : "+c.getContact());
		  System.out.println("---------------------------------------");
	  }
	  System.out.println("done.....");
}
public void dueAmount(List<Customer> customer)
{

}
public void lastPayment(List<Customer> customer)
{

}
public void emiCalculation(List<Customer> customer)
{
	}

}
