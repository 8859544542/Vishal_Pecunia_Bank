package com.capgemini.myapp.exe;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.myapp.appres.LocationInfo;
import com.capgemini.myapp.dto.Customer;
import com.capgemini.myapp.dto.Employee;
import com.capgemini.myapp.service.CustomerService;
import com.capgemini.myapp.ui.CustomerUi;
import com.capgemini.myapp.ui.EmployeeUi;
import com.capgemini.myapp.ui.ManagerUi;

public class main implements Serializable {

	public static void main(String[] args) {

		boolean b1 = false;
		boolean b2 = false;

		System.out.println("1 for Manager ");
		System.out.println("2 for Employee ");
		System.out.println("3 for Customer ");
		System.out.println("4 for quit");
		FileInputStream fout = null;
		ObjectInputStream oos = null;

		List<Employee> employee = new ArrayList();
		List<Customer> customer = new ArrayList();
		Scanner scanner = new Scanner(System.in);

		try {

			File fc = new File(LocationInfo.pathCustomer);
			File fe = new File(LocationInfo.pathEmployee);

			b1 = fc.exists();
			b2 = fe.exists();

		} catch (Exception e) {
			// TODO: handle exception
		}

		if (b1 && b2)

		{
			try {
				fout = new FileInputStream(LocationInfo.pathCustomer);
				oos = new ObjectInputStream(fout);
				Object obj = oos.readObject();
				if (obj != null) {
					customer = (List<Customer>) obj;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				fout = new FileInputStream(LocationInfo.pathEmployee);
				oos = new ObjectInputStream(fout);
				Object obj = oos.readObject();
				if (obj != null) {
					employee = (List<Employee>) obj;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		} // end of if file exist check

		switch (scanner.nextInt()) {
		case 1:
			try {
				new ManagerUi().login(employee, customer);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			break;
		case 2:
			new EmployeeUi().Employeelogin(employee, customer);
			break;
		case 3:
			new CustomerUi().customerLogin(customer);
			break;
		case 4:
			System.exit(0);
			break;

		default:
			System.out.println("wrong choice....");

		}

	}
}
