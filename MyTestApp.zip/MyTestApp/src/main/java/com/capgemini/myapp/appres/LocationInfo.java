package com.capgemini.myapp.appres;

public class LocationInfo {

	public static String pathCustomer = "C:\\STS\\MyTestApp\\src\\main\\resources\\customer.txt";
	public static String pathEmployee = "C:\\STS\\MyTestApp\\src\\main\\resources\\employee.txt";
	
}
