package com.capgemini.myapp.ui;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.myapp.appres.LocationInfo;
import com.capgemini.myapp.dto.Customer;
import com.capgemini.myapp.dto.Employee;
import com.capgemini.myapp.service.ManagerService;

public class ManagerUi implements Serializable {
   Scanner scanner=new Scanner(System.in);
  
   
	 public void login( List<Employee> employee, List<Customer> customer) throws FileNotFoundException
	 {  
		 System.out.println("enter user id ...");
		 int id=scanner.nextInt();
		 scanner.nextLine();
		 System.out.println("enter user password...");
		 String password=scanner.nextLine();
		 if(id==123 && password.equals("123"))
		 {
			    System.out.println("1 for view All Customer ");
				System.out.println("2 for total Loan Report");
				System.out.println("3 for create Employee ");
			    System.out.println("4 for delete Employee");
				System.out.println("5 for view Customer ");
				System.out.println("6 for view Employee ");
				System.out.println("7 for quit");
		        Scanner scanner=new Scanner(System.in);
		        ManagerService ms=new ManagerService();
		        List<Employee> emp=employee;
		        List<Customer> cust=customer;
				switch(scanner.nextInt())
				{
				case 1:	
					    cust=ms.viewAllCustomer(customer);
						break;
				case 2:
					    cust=ms.totalLoanReport(customer);
						break;
				case 3:
					 	emp =ms.createEmployee(employee);
						break;
				case 4:
						emp=ms.deleteEmployee(employee );
						break;
				case 5:
					    cust=ms.viewCustomer( customer );
						 break;
				case 6:
					    emp=ms.viewAllEmployee(employee);
						break;
				case 7:
						System.exit(0);
						break;
				default:
						System.out.println("wrong choice....");
					
				
				}
				try {
					FileOutputStream fout = new FileOutputStream(LocationInfo.pathEmployee);
				 	ObjectOutputStream oos = new ObjectOutputStream(fout);
				 	try {
						oos.writeObject(emp);
					} catch (IOException e) {
						e.printStackTrace();
					}
				}catch(Exception e) {
					e.printStackTrace();
				}
				try {
					FileOutputStream fout = new FileOutputStream(LocationInfo.pathCustomer);
				 	ObjectOutputStream oos = new ObjectOutputStream(fout);
				 	try {
						oos.writeObject(cust);
					} catch (IOException e) {
						e.printStackTrace();
					}
				}catch(Exception e) {
					e.printStackTrace();
				}
			 
		 }else
				System.out.println("Invalid User Id and password ");
		 
		 
	 }
}
