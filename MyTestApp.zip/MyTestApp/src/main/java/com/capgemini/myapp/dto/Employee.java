package com.capgemini.myapp.dto;

import java.io.Serializable;

public class Employee implements Serializable{

private String empid;
private String empname;
private String designation;
private String branchid;
private String password;

public Employee() {
	super();
	// TODO Auto-generated constructor stub
}
public Employee(String empid, String empname, String designation, String branchid, String password) {
	super();
	this.empid = empid;
	this.empname = empname;
	this.designation = designation;
	this.branchid = branchid;
	this.password = password;
}
public String getEmpid() {
	return empid;
}
public void setEmpid(String empid) {
	this.empid = empid;
}
public String getEmpname() {
	return empname;
}
public void setEmpname(String empname) {
	this.empname = empname;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}
public String getBranchid() {
	return branchid;
}
public void setBranchid(String branchid) {
	this.branchid = branchid;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
}
