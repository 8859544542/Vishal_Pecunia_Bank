package com.capgemini.myapp.dto;

public class Address {

	private String addressid;
	private String addressline1;
	private String addressline2;
	private String addresscity;
	private String addressstate;
	private String addresscountry;
	private String addresszipcode;
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Address(String addressid, String addressline1, String addressline2, String addresscity, String addressstate,
			String addresscountry, String addresszipcode) {
		super();
		this.addressid = addressid;
		this.addressline1 = addressline1;
		this.addressline2 = addressline2;
		this.addresscity = addresscity;
		this.addressstate = addressstate;
		this.addresscountry = addresscountry;
		this.addresszipcode = addresszipcode;
	}
	public String getAddressid() {
		return addressid;
	}
	public void setAddressid(String addressid) {
		this.addressid = addressid;
	}
	public String getAddressline1() {
		return addressline1;
	}
	public void setAddressline1(String addressline1) {
		this.addressline1 = addressline1;
	}
	public String getAddressline2() {
		return addressline2;
	}
	public void setAddressline2(String addressline2) {
		this.addressline2 = addressline2;
	}
	public String getAddresscity() {
		return addresscity;
	}
	public void setAddresscity(String addresscity) {
		this.addresscity = addresscity;
	}
	public String getAddressstate() {
		return addressstate;
	}
	public void setAddressstate(String addressstate) {
		this.addressstate = addressstate;
	}
	public String getAddresscountry() {
		return addresscountry;
	}
	public void setAddresscountry(String addresscountry) {
		this.addresscountry = addresscountry;
	}
	public String getAddresszipcode() {
		return addresszipcode;
	}
	public void setAddresszipcode(String addresszipcode) {
		this.addresszipcode = addresszipcode;
	}
}
