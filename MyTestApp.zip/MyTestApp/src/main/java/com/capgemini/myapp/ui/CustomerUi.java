package com.capgemini.myapp.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.myapp.dto.Customer;
import com.capgemini.myapp.service.CustomerService;
import com.capgemini.myapp.service.ManagerService;

public class CustomerUi {
	Scanner scanner=new Scanner(System.in);
	public void customerLogin(List<Customer> customer)
	{
		 System.out.println("enter user id ...");
		 String str=scanner.nextLine();
		 System.out.println("enter password...");
		 String password=scanner.nextLine();
		 for(Customer cs1:customer)
		 {
		 if(str==cs1.getCustid() && password==cs1.getCustpass())
		 {
			    System.out.println("1 for View_details ");
				System.out.println("2 for Due_Amount");
				System.out.println("3 for Last_payment ");
			    System.out.println("4 for emi calculation ");
				System.out.println("5 for quit");
		        CustomerService cs=new CustomerService();
				switch(scanner.nextInt())
				{
				case 1:cs.viewDetails(customer);
					break;
				case 2:cs.dueAmount(customer );
					break;
				case 3:cs.lastPayment( customer );
				   break;
				case 4:cs.emiCalculation(customer );
				   break;
				case 5:System.exit(0);
				
				default:System.out.println("wrong choice....");
					
				
				}
			 
		 }
		 else
		 {
			 System.out.println("invalid user ....");
		 }
		 
		}
	}
	
}
